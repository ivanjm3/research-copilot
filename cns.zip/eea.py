def eea(a, b):
    if b == 0:
        return a, 1, 0
    else:
        gcd, x1, y1 = eea(b, a % b)
        x = y1
        y = x1 - (a // b) * y1
        return gcd, x, y


def modInverse(a, m):
    gcd, x, y = eea(a, m)
    if gcd != 1:
        return None
    else:
        return x % m


a = int(input())
b = int(input())

gcd, x, y = eea(a, b)

print("GCD:", gcd)
print("x:", x)
print("y:", y)

print("Mod inv:", modInverse(a, b))