def eea(a, b):
    if b==0:
        return a, 1, 0
    else:
        gcd, x1, y1 = eea(b, a%b)
        x= y1
        y= x1 - (a//b)*y1
        return gcd, x, y

def modInverse(a, m):
    gcd, x, y = eea(a, m)
    if gcd != 1:
        return None
    return x%m

p = int(input())
q = int(input())
e = int(input())


n = p*q
phi = (p-1)*(q-1)
d = modInverse(e, phi)

print("public key (e,n):", (e,n))
print("private key (d,n):", (d,n))


message = int(input())

cipher = pow(message, e, n)
print("encrypted ", cipher)

decrypted = pow(cipher, d, n)
print("decrypted ", decrypted)