P10 = [3,5,2,7,4,10,1,9,8,6]
P8 = [6,3,7,4,8,5,10,9]
IP = [2,6,3,1,4,8,5,7]
IP_INV = [4,1,3,5,7,2,8,6]
EP = [4,1,2,3,2,3,4,1]
P4 = [2,4,3,1]

S0 = [[1,0,3,2],
      [3,2,1,0],
      [0,2,1,3],
      [3,1,3,2]]

S1 = [[0,1,2,3],
      [2,0,1,3],
      [3,0,1,0],
      [2,1,0,3]]


def permute(bits, table):
    return ''.join(bits[i-1] for i in table)


def left_shift(bits, n):
    return bits[n:] + bits[:n]


def xor(a, b):
    return ''.join('0' if a[i] == b[i] else '1' for i in range(len(a)))


def sbox_lookup(bits, box):
    row = int(bits[0] + bits[3], 2)
    col = int(bits[1] + bits[2], 2)
    return format(box[row][col], '02b')


def generate_keys(key):
    key = permute(key, P10)
    left, right = key[:5], key[5:]

    left = left_shift(left, 1)
    right = left_shift(right, 1)
    K1 = permute(left + right, P8)

    left = left_shift(left, 2)
    right = left_shift(right, 2)
    K2 = permute(left + right, P8)

    return K1, K2


def fk(bits, key):
    left, right = bits[:4], bits[4:]

    temp = permute(right, EP)
    temp = xor(temp, key)

    left_sbox = sbox_lookup(temp[:4], S0)
    right_sbox = sbox_lookup(temp[4:], S1)

    temp = permute(left_sbox + right_sbox, P4)
    left = xor(left, temp)

    return left + right


def sdes_encrypt(plaintext, key):
    K1, K2 = generate_keys(key)

    bits = permute(plaintext, IP)
    bits = fk(bits, K1)

    bits = bits[4:] + bits[:4]  # swap

    bits = fk(bits, K2)
    return permute(bits, IP_INV)


def sdes_decrypt(ciphertext, key):
    K1, K2 = generate_keys(key)

    bits = permute(ciphertext, IP)
    bits = fk(bits, K2)

    bits = bits[4:] + bits[:4]

    bits = fk(bits, K1)
    return permute(bits, IP_INV)


# Input
key = input("Enter 10-bit key: ")
plaintext = input("Enter 8-bit plaintext: ")

cipher = sdes_encrypt(plaintext, key)
print("Encrypted:", cipher)

decrypted = sdes_decrypt(cipher, key)
print("Decrypted:", decrypted)