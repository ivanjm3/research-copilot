def gmul(a, b):
    p = 0
    for i in range(8):
        if b & 1:
            p ^= a
        high_bit = a & 0x80
        a <<= 1
        if high_bit:
            a ^= 0x11B
        a &= 0xFF
        b >>= 1
    return p



def mix_column(column):
    return [
        gmul(column[0], 2) ^ gmul(column[1], 3) ^ column[2] ^ column[3],
        column[0] ^ gmul(column[1], 2) ^ gmul(column[2], 3) ^ column[3],
        column[0] ^ column[1] ^ gmul(column[2], 2) ^ gmul(column[3], 3),
        gmul(column[0], 3) ^ column[1] ^ column[2] ^ gmul(column[3], 2)
    ]


def inv_mix_column(column):
    return [
        gmul(column[0], 0x0E) ^ gmul(column[1], 0x0B) ^ gmul(column[2], 0x0D) ^ gmul(column[3], 0x09),
        gmul(column[0], 0x09) ^ gmul(column[1], 0x0E) ^ gmul(column[2], 0x0B) ^ gmul(column[3], 0x0D),
        gmul(column[0], 0x0D) ^ gmul(column[1], 0x09) ^ gmul(column[2], 0x0E) ^ gmul(column[3], 0x0B),
        gmul(column[0], 0x0B) ^ gmul(column[1], 0x0D) ^ gmul(column[2], 0x09) ^ gmul(column[3], 0x0E)
    ]


column = [0xdb, 0x13, 0x53, 0x45]

mixed = mix_column(column)
print("MixColumn:", [hex(x) for x in mixed])

restored = inv_mix_column(mixed)
print("Inverse MixColumn:", [hex(x) for x in restored])