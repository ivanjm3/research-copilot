def eea(a, b):
    if b == 0:
        return a, 1, 0
    else:
        gcd, x1, y1 = eea(b, a % b)
        x = y1
        y = x1 - (a // b) * y1
        return gcd, x, y


def modInverse(a, m):
    gcd, x, y = eea(a, m)
    if gcd != 1:
        return None
    return x % m


# Public parameters
p = int(input("Enter prime p: "))
g = int(input("Enter generator g: "))

# Bob's private key
x = int(input("Enter receiver private key x: "))

# Public key
y = pow(g, x, p)
print("Public key (p,g,y):", (p, g, y))

# Encryption
M = int(input("Enter message (< p): "))
k = int(input("Enter random k: "))

c1 = pow(g, k, p)
c2 = (M * pow(y, k, p)) % p

print("Ciphertext:", (c1, c2))

# Decryption
s = pow(c1, x, p)
s_inv = modInverse(s, p)

M_decrypted = (c2 * s_inv) % p

print("Decrypted message:", M_decrypted)