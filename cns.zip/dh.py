p = int(input("Enter prime p"))
g = int(input("Enter primitive root g"))

#prct kets
a = int(input("As private key: "))
b = int(input("Bs private key: "))

#pub values 
A = pow(g, a, p)
B = pow(g, b, p)


print("Alice sends ", A)
print("Bob sends ", B)

# shared secret
key_alice = pow(B,a,p)
key_bob = pow(A,b,p)

print("Shared key (Alice):", key_alice)
print("Shared key (Bob):", key_bob)