def generate_matrix(key):
    key = key.upper().replace("J", "I")
    seen = set()
    matrix = []

    for char in key:
        if char.isalpha() and char not in seen:
            matrix.append(char)
            seen.add(char)

    for char in "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if char not in seen:
            matrix.append(char)
            seen.add(char)

    return [matrix[i:i+5] for i in range(0, 25, 5)]


def find_pos(matrix, char):
    for i in range(5):
        for j in range(5):
            if matrix[i][j] == char:
                return i, j


def prepare_text(text):
    text = text.upper().replace("J", "I")
    text = "".join([c for c in text if c.isalpha()])
    res = ""
    i = 0

    while i < len(text):
        a = text[i]

        if i + 1 < len(text):
            b = text[i + 1]
            if a == b:
                res += a + "X"
                i += 1
            else:
                res += a + b
                i += 2
        else:
            res += a + "X"
            i += 1

    return res


def playfair(matrix, text, mode):
    res = ""

    for i in range(0, len(text), 2):
        a, b = text[i], text[i+1]
        r1, c1 = find_pos(matrix, a)
        r2, c2 = find_pos(matrix, b)

        if r1==r2:
            if mode!="decrypt":
                res += matrix[r1][(c1+1)%5]
                res += matrix[r1][(c2+1)%5]
            else:
                res += matrix[r1][(c1-1)%5]
                res += matrix[r1][(c2-1)%5]
        elif c1==c2:
            if mode!="decrypt":
                res += matrix[(r1+1)%5][c1]
                res += matrix[(r2+1)%5][c1]
            else:
                res += matrix[(r1-1)%5][c1]
                res += matrix[(r2-1)%5][c1]
        
        else:
                res += matrix[r1][c2]
                res += matrix[r2][c1]
    return res
    

key = input()
matrix = generate_matrix(key)
choice = input()
if choice == "encrypt":
    text = input("Enter plaintext: ")
    text = prepare_text(text)
else:
    text = input("Enter ciphertext: ").upper()
    text = "".join([c for c in text if c.isalpha()])

print(playfair(matrix,text,choice))

