def hill(text, key_matrix, mode):
    mod = 26
    n = len(key_matrix)

    text = text.upper().replace(" ", "")
    while len(text) % n != 0:
        text += 'X'

    # -------- Determinant --------
    def determinant(m):
        if n == 2:
            return (m[0][0]*m[1][1] - m[0][1]*m[1][0]) % mod
        return (
            m[0][0]*(m[1][1]*m[2][2] - m[1][2]*m[2][1])
            - m[0][1]*(m[1][0]*m[2][2] - m[1][2]*m[2][0])
            + m[0][2]*(m[1][0]*m[2][1] - m[1][1]*m[2][0])
        ) % mod

    # -------- Adjugate --------
    def adjugate(m):
        if n == 2:
            return [
                [ m[1][1], -m[0][1] ],
                [ -m[1][0], m[0][0] ]
            ]

        adj = [[0]*3 for _ in range(3)]

        adj[0][0] =  (m[1][1]*m[2][2] - m[1][2]*m[2][1])
        adj[0][1] = -(m[1][0]*m[2][2] - m[1][2]*m[2][0])
        adj[0][2] =  (m[1][0]*m[2][1] - m[1][1]*m[2][0])

        adj[1][0] = -(m[0][1]*m[2][2] - m[0][2]*m[2][1])
        adj[1][1] =  (m[0][0]*m[2][2] - m[0][2]*m[2][0])
        adj[1][2] = -(m[0][0]*m[2][1] - m[0][1]*m[2][0])

        adj[2][0] =  (m[0][1]*m[1][2] - m[0][2]*m[1][1])
        adj[2][1] = -(m[0][0]*m[1][2] - m[0][2]*m[1][0])
        adj[2][2] =  (m[0][0]*m[1][1] - m[0][1]*m[1][0])

        # transpose
        return [[adj[j][i] for j in range(3)] for i in range(3)]

    # -------- Inverse Matrix --------
    def inverse_matrix(m):
        det = determinant(m)
        det_inv = pow(det, -1, mod)  # built-in modular inverse
        adj = adjugate(m)
        return [[(adj[i][j] * det_inv) % mod for j in range(n)] for i in range(n)]

    if mode == "decrypt":
        key_matrix = inverse_matrix(key_matrix)

    # -------- Matrix × Vector --------
    def multiply(m, vec):
        return [
            sum(m[i][j] * vec[j] for j in range(n)) % mod
            for i in range(n)
        ]

    result = ""

    for i in range(0, len(text), n):
        block = [ord(c) - 65 for c in text[i:i+n]]
        encrypted = multiply(key_matrix, block)
        result += ''.join(chr(num + 65) for num in encrypted)

    return result


# -------- MAIN --------
text = input("Text: ")
n = int(input("n (2 or 3): "))

print(f"Enter key matrix ({n}x{n}) row by row:")
key_matrix = [list(map(int, input().split())) for _ in range(n)]

mode = input("Mode (encrypt/decrypt): ")

print(hill(text, key_matrix, mode))