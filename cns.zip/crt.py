def eea(a, b):
    if b == 0:
        return a, 1, 0
    else:
        gcd, x1, y1 = eea(b, a % b)
        x = y1
        y = x1 - (a // b) * y1
        return gcd, x, y


def modInverse(a, m):
    gcd, x, y = eea(a, m)
    if gcd != 1:
        return None
    return x % m


def chinese_remainder(a, m):
    n = len(a)
    M = 1
    
    # Step 1: Compute total modulus
    for mi in m:
        M *= mi
    
    result = 0
    
    # Step 2: Apply formula
    for i in range(n):
        Mi = M // m[i]
        yi = modInverse(Mi, m[i])
        result += a[i] * Mi * yi
    
    return result % M


# Example usage
a = [int(x) for x in input("Enter remainders: ").split()]
m = [int(x) for x in input("Enter moduli: ").split()]

print("Solution:", chinese_remainder(a, m))