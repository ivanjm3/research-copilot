def caesar(text, key, mode):
    if mode == "decrypt":
        key = -key
    key %= 26
    res = ""
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            res += chr((ord(char)-base+key)%26+base)
        else:
            res += char
    return res
    
text = input()
key = int(input())
mode = input()
print(caesar(text,key,mode))