p = int(input("Enter prime p: "))
g = int(input("Enter primitive root g: "))

# Private keys
a = int(input("Alice private key: "))
b = int(input("Bob private key: "))
m = int(input("Attacker private key: "))

# Public values
A = pow(g, a, p)  # Alice sends
B = pow(g, b, p)  # Bob sends

# Attacker intercepts and sends own values
M1 = pow(g, m, p)  # Sent to Alice
M2 = pow(g, m, p)  # Sent to Bob

# Shared keys
key_alice = pow(M1, a, p)   # Alice thinks this is Bob's
key_bob = pow(M2, b, p)     # Bob thinks this is Alice's

key_attacker_with_alice = pow(A, m, p)
key_attacker_with_bob = pow(B, m, p)

print("\nAlice's key:", key_alice)
print("Bob's key:", key_bob)

print("Attacker key with Alice:", key_attacker_with_alice)
print("Attacker key with Bob:", key_attacker_with_bob)